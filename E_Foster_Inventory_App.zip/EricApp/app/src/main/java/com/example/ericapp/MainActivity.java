package com.example.ericapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView inventoryGrid;
    private FloatingActionButton fabAddItem, fabRemoveItem;
    private TextView inventoryHeader;
    private InventoryAdapter inventoryAdapter;
    private List<InventoryItem> inventoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Reference UI components
        inventoryHeader = findViewById(R.id.inventoryHeader);
        inventoryGrid = findViewById(R.id.inventoryGrid);
        fabAddItem = findViewById(R.id.fabAddItem);
        fabRemoveItem = findViewById(R.id.fabRemoveItem);

        // RecyclerView grid with 2 columns - Does not show anything in the design view unless you use xmlns:tools="http://schemas.android.com/tools"
        // in activity_main.xml to lie to the emulator. DO this or lose lots of hours trying to see what is generally only seen at run time.
        inventoryGrid.setLayoutManager(new GridLayoutManager(this, 2));

        // Sample data for the inventory (these items will also not be seen until runtime, the data on the design layout is for representation of layout and
        // not specific content that is hard coded
        inventoryList = new ArrayList<>();
        inventoryList.add(new InventoryItem("Item A", 5));
        inventoryList.add(new InventoryItem("Item B", 2));
        inventoryList.add(new InventoryItem("Item C", 0));

        // Hook up adapter
        inventoryAdapter = new InventoryAdapter(inventoryList);
        inventoryGrid.setAdapter(inventoryAdapter);

        // FAB listeners
        fabAddItem.setOnClickListener(view -> addItem());
        fabRemoveItem.setOnClickListener(view -> removeItem());
    }

    private void addItem() {
        inventoryList.add(new InventoryItem("New Item", 1));
        inventoryAdapter.notifyItemInserted(inventoryList.size() - 1);
    }

    private void removeItem() {
        if (!inventoryList.isEmpty()) {
            int lastIndex = inventoryList.size() - 1;
            inventoryList.remove(lastIndex);
            inventoryAdapter.notifyItemRemoved(lastIndex);
        }
    }
}
