package com.example.ericapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * central SQLite database helper for the Stack N Stock app.
 * this class
 *  - creates database schema on first run
 *  - handles upgrades when the DB version changes
 *  - provides table name constants for repositories
 */
public class AppDatabase extends SQLiteOpenHelper {
    // DB file name
    public static final String DB_NAME = "stack_n_stock.db";

    // change this value if you change the schema
    public static final int DB_VERSION = 1;

    // tables
    public static final String T_USERS = "users";
    public static final String T_INVENTORY = "inventory";

    /**
     * constructor.
     */
    public AppDatabase(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    /**
     * called when the database is created for the first time.
     * defines schema for user accounts and inventory items.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // create table for users
        db.execSQL(
                "CREATE TABLE " + T_USERS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," + // unique ID
                        "username TEXT UNIQUE NOT NULL," +        // login username
                        "password_hash TEXT NOT NULL," +          // stored password
                        "phone TEXT)"                             // optional phone for SMS alerts
        );

        // Create table for inventory, linked to a user by username
        db.execSQL(
                "CREATE TABLE " + T_INVENTORY + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," + // unique ID
                        "username TEXT NOT NULL," +               // owner of the item
                        "name TEXT NOT NULL," +                   // item name
                        "quantity INTEGER NOT NULL DEFAULT 0," +  // item quantity
                        // Prevent duplicate items per user; replace if conflict occurs(upsert)
                        "UNIQUE(username, name) ON CONFLICT REPLACE)"
        );
    }

    /**
     * Called when the DB version increases. Runs incremental, transactional
     * migrations without dropping data. Bump DB_VERSION when creating a new step.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.beginTransaction();
        try {
            // example migration: 1 -> 2
            // adds a created_at column to inventory without losing data
            if (oldVersion < 2) {
                // only add if it does not already exist
                try {
                    db.execSQL("ALTER TABLE " + T_INVENTORY + " ADD COLUMN created_at INTEGER DEFAULT (strftime('%s','now'))");
                } catch (Exception ignored) { /* column may already exist */ }
            }

            // example migration: 2 -> 3
            // rebuilds users table to normalize usernames to lowercase
            if (oldVersion < 3) {
                db.execSQL("CREATE TABLE IF NOT EXISTS users_new (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "username TEXT UNIQUE NOT NULL," +
                        "password_hash TEXT NOT NULL," +
                        "phone TEXT)");
                db.execSQL("INSERT OR IGNORE INTO users_new (id, username, password_hash, phone) " +
                        "SELECT id, lower(username), password_hash, phone FROM " + T_USERS);
                db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
                db.execSQL("ALTER TABLE users_new RENAME TO " + T_USERS);
            }

            //
            // if (oldVersion < 4) { ... }

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
}