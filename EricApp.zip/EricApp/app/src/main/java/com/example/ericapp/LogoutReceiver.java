package com.example.ericapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * BroadcastReceiver that clears the saved login session when the device is shutting down.
 * SECURITY / SAFETY:
 * - verify broadcast action with getAction().
 * - ignores any unexpected or null actions to avoid accidental session wipes.
 */
public class LogoutReceiver extends BroadcastReceiver {

    private static final String TAG = "LogoutReceiver";
    private static final String ACTION_SHUTDOWN = Intent.ACTION_SHUTDOWN;

    @Override
    public void onReceive(Context context, Intent intent) {
        // defensive ninja move: null-check the Intent
        if (intent == null) {
            Log.w(TAG, "onReceive: null Intent, ignoring.");
            return;
        }

        // get the broadcast action and verify it matches expected values
        final String action = intent.getAction();
        if (action == null) {
            Log.w(TAG, "onReceive: null action, ignoring.");
            return;
        }

        // do not get trigger happy, only act on device shutdown; ignore everything else
        if (ACTION_SHUTDOWN.equals(action)) {
            Log.i(TAG, "Device shutdown detected. Cleaning up.");
            context.getSharedPreferences("session", Context.MODE_PRIVATE)
                    .edit()
                    .clear()
                    .apply();
        } else {
            // ignore any other broadcasts (safety first)
            Log.d(TAG, "onReceive: Unhandled action \"" + action + "\", no-op.");
        }
    }
}