package com.example.ericapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity

 * handles login and account creation.
 * - if a session is already active, jump over login and dump to MainActivity.
 * - allows log in with existing credentials.
 * - allows account creation.
 * - successful login dumps user to SMS permission screen before granting session.
 */
public class LoginActivity extends AppCompatActivity {
    private EditText editUsername, editPassword;  // input fields
    private Button btnLogin, btnCreateAccount;    // buttons for actions

    private UserRepository users; // user storage/validation repo

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //  is user already logged in and session is active
        String savedUser = getSharedPreferences("session", MODE_PRIVATE)
                .getString("username", null);
        boolean sessionActive = getSharedPreferences("session", MODE_PRIVATE)
                .getBoolean("session_active", false);

        // if so, dump to main app
        if (savedUser != null && sessionActive) {
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra("username", savedUser);
            startActivity(i);
            finish();
            return; // exit early, no need for login screen
        }

        // otherwise, show login screen
        setContentView(R.layout.activity_login);
        setTitle("Stack N Stock");

        users = new UserRepository(this); // init repo for user data

        //  UI element connect
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        // button click listeners
        btnLogin.setOnClickListener(v -> doLogin());
        btnCreateAccount.setOnClickListener(v -> doCreate());

        // exit app when "X" FAB is tapped
        findViewById(R.id.fabExitLogin).setOnClickListener(v -> finishAffinity());
    }

    /**
     * attempt log in
     * - input validation
     * - checks credentials via UserRepository
     * - if valid, stores username and moves to SMS permission activity
     */
    private void doLogin() {
        String u = editUsername.getText().toString().trim();
        String p = editPassword.getText().toString();

        //  fields are not empty
        if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
            android.widget.Toast.makeText(
                    this, "Please Enter Username and Password.",
                    android.widget.Toast.LENGTH_SHORT).show();
            return;
        }

        // check user credentials
        if (users.validateLogin(u, p)) {
            // save the username (session not yet active)
            getSharedPreferences("session", MODE_PRIVATE)
                    .edit()
                    .putString("username", u)
                    .apply();

            // SMS permission screen redirect (final step before session activation)
            Intent i = new Intent(this, SmsPermissionActivity.class);
            i.putExtra("username", u);
            startActivity(i);
            finish();
        } else {
            // invalid login
            android.widget.Toast.makeText(
                    this, "Step to the side please!. If you are new please create an account. otherwise enter valid credentials",
                     android.widget.Toast.LENGTH_LONG).show();
        }
    }

    /**
     * attempt to create a new account with given username and password.
     * - input validation
     * - UserRepository call to insert new user
     */
    private void doCreate() {
        String u = editUsername.getText().toString().trim();
        String p = editPassword.getText().toString();

        // require both fields
        if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
            android.widget.Toast.makeText(this, "Please enter desired username and password.", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }

        // Try to insert user into DB
        boolean ok = users.createUser(u, p, null);
        if (ok) {
            android.widget.Toast.makeText(this, "Account created. Please log in.", android.widget.Toast.LENGTH_SHORT).show();
        } else {
            android.widget.Toast.makeText(this, "Username already exists.", android.widget.Toast.LENGTH_LONG).show();
        }
    }
}