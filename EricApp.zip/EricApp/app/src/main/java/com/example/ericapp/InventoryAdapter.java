package com.example.ericapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * RecyclerView Adapter for displaying and interacting with inventory items.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    /**
     * listener to handle item quantity updates and deletion.
     */
    public interface QuantityListener {
        void onIncrease(InventoryItem item, int position); // + button trigger
        void onDecrease(InventoryItem item, int position); // - button trigger
        void onDelete(InventoryItem item, int position);   // long press trigger
    }

    private final List<InventoryItem> items;   // inventory items displayed in RecyclerView
    private final QuantityListener listener;   //  item action callback

    public InventoryAdapter(List<InventoryItem> items, QuantityListener listener) {
        this.items = items;
        this.listener = listener;
    }

    /**
     * inventory item row inflater.
     */
    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory_tile, parent, false);
        return new InventoryViewHolder(v);
    }

    /**
     * Bind data (item name and quantity) and set up button click listeners.
     */
    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = items.get(position);

        // display name and quantity
        holder.itemName.setText(item.getName());
        holder.quantityView.setText(String.valueOf(item.getQuantity()));

        // plus button click handler
        holder.btnIncrease.setOnClickListener(v -> {
            if (listener == null) return;
            int pos = holder.getAdapterPosition();
            if (pos == RecyclerView.NO_POSITION) return; // safety check was row removed
            listener.onIncrease(items.get(pos), pos);
        });

        // minus button click handler
        holder.btnDecrease.setOnClickListener(v -> {
            if (listener == null) return;
            int pos = holder.getAdapterPosition();
            if (pos == RecyclerView.NO_POSITION) return;
            listener.onDecrease(items.get(pos), pos);
        });

        // long press handler
        holder.itemView.setOnLongClickListener(v -> {
            if (listener == null) return true;
            int pos = holder.getAdapterPosition();
            if (pos == RecyclerView.NO_POSITION) return true;
            listener.onDelete(items.get(pos), pos);
            return true; // eat the long press
        });
    }

    /**
     * returns total number of items in list.
     */
    @Override
    public int getItemCount() {
        return items.size();
    }

    /**
     * viewHolder class.
     */
    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, quantityView;  // UI display for item name and quantity
        Button btnIncrease, btnDecrease;  // buttons for adjusting quantity

        InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            quantityView = itemView.findViewById(R.id.itemQuantity);
            btnIncrease = itemView.findViewById(R.id.btnIncrease);
            btnDecrease = itemView.findViewById(R.id.btnDecrease);
        }
    }
}