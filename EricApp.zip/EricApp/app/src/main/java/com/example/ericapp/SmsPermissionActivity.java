package com.example.ericapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final String PREFS = "sms_prefs";
    private String username;
    private UserRepository userRepo;

    private final ActivityResultLauncher<String> requestSmsPerm =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    onPermissionGranted();
                } else {
                    onPermissionDenied();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);
        setTitle("Stack N Stock");

        username = getIntent().getStringExtra("username");
        if (username == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        userRepo = new UserRepository(this);

        Button grant = findViewById(R.id.btnGrantSms);
        Button deny = findViewById(R.id.btnDenySms);

        grant.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                onPermissionGranted();
            } else {
                requestSmsPerm.launch(Manifest.permission.SEND_SMS);
            }
        });

        deny.setOnClickListener(v -> onPermissionDenied());
    }

    private void onPermissionGranted() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putBoolean("sms_enabled", true).apply();

        // Prompt for phone number once
        final EditText input = new EditText(this);
        input.setHint("Enter your phone number");
        input.setInputType(InputType.TYPE_CLASS_PHONE);
        LinearLayout container = new LinearLayout(this);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        container.setPadding(pad, pad, pad, pad);
        container.addView(input);

        new AlertDialog.Builder(this)
                .setTitle("SMS Alerts")
                .setMessage("Enter a phone number to receive low-inventory alerts.")
                .setView(container)
                .setPositiveButton("Save", (d, w) -> {
                    String phone = input.getText().toString().trim();
                    if (!phone.isEmpty()) userRepo.setPhone(username, phone);
                    activateSessionAndGoToMain();
                })
                .setNegativeButton("Skip", (d, w) -> activateSessionAndGoToMain())
                .setCancelable(false)
                .show();
    }

    private void onPermissionDenied() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putBoolean("sms_enabled", false).apply();
        Toast.makeText(this, "SMS permission denied. App will still work.", Toast.LENGTH_SHORT).show();
        activateSessionAndGoToMain();
    }

    private void activateSessionAndGoToMain() {
        // Mark session as active so future launches skip login correctly
        getSharedPreferences("session", MODE_PRIVATE)
                .edit()
                .putBoolean("session_active", true)
                .apply();

        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("username", username);
        startActivity(i);
        finish();
    }
}