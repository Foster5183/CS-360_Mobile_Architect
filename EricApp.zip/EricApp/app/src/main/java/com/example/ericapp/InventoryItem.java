package com.example.ericapp;

public class InventoryItem {
    private String name;
    private int quantity;
//mutator and accessor methods for items
    public InventoryItem(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
