package com.example.ericapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class UserRepository {
    private final AppDatabase dbHelper;

    public UserRepository(Context ctx) {
        this.dbHelper = new AppDatabase(ctx);
    }

    public boolean createUser(String username, String plainPassword, String phone) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username.trim());
        cv.put("password_hash", sha256(plainPassword));
        if (phone != null) cv.put("phone", phone.trim());
        long id = db.insert(AppDatabase.T_USERS, null, cv);
        return id != -1;
    }

    public boolean validateLogin(String username, String plainPassword) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(AppDatabase.T_USERS,
                new String[]{"password_hash"},
                "username=?",
                new String[]{username.trim()},
                null, null, null);
        boolean ok = false;
        if (c.moveToFirst()) {
            String stored = c.getString(0);
            ok = stored.equals(sha256(plainPassword));
        }
        c.close();
        return ok;
    }

    public String getPhone(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(AppDatabase.T_USERS,
                new String[]{"phone"},
                "username=?",
                new String[]{username.trim()}, null, null, null);
        String phone = null;
        if (c.moveToFirst()) phone = c.getString(0);
        c.close();
        return phone;
    }

    public void setPhone(String username, String phone) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("phone", phone);
        db.update(AppDatabase.T_USERS, cv, "username=?", new String[]{username.trim()});
    }

    private static String sha256(String input) {
        try {
            MessageDigest d = MessageDigest.getInstance("SHA-256");
            byte[] hash = d.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return input; // fallback (should never happen)
        }
    }
}