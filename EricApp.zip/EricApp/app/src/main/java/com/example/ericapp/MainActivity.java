package com.example.ericapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity
 * ---------------------------------------------------
 * Displays the inventory grid for the logged-in user.
 * Allows CRUD operations (add, remove, update, delete)
 * on inventory items stored in SQLite.
 * -database persistence using InventoryRepository
 * - add / remove buttons
 * - exit button clears session + closes app and tidy's up
 * - low stock SMS alerts (that is if the user enabled permission)
 */
public class MainActivity extends AppCompatActivity {

    // UI elements
    private RecyclerView inventoryGrid;
    private FloatingActionButton fabAddItem, fabRemoveItem, fabExit;
    private TextView inventoryHeader;

    // adapter + backing list for RecyclerView
    private InventoryAdapter inventoryAdapter;
    private final List<InventoryItem> inventoryList = new ArrayList<>();

    // data repositories
    private InventoryRepository inventoryRepo;
    private UserRepository userRepo;

    // current logged-in username
    private String username;

    // triggering low-stock SMS alerts
    private static final int LOW_STOCK_THRESHOLD = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Stack N Stock");

        // if no username passed, dump back to login
        username = getIntent().getStringExtra("username");
        if (username == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // initialize DB repos
        inventoryRepo = new InventoryRepository(this);
        userRepo = new UserRepository(this);

        // bind UI
        inventoryHeader = findViewById(R.id.inventoryHeader);
        inventoryGrid = findViewById(R.id.inventoryGrid);
        fabAddItem = findViewById(R.id.fabAddItem);
        fabRemoveItem = findViewById(R.id.fabRemoveItem);
        fabExit = findViewById(R.id.fabExit);

        // 2-column grid layout for inventory
        inventoryGrid.setLayoutManager(new GridLayoutManager(this, 2));

        //  items from DB load out for existing user
        inventoryList.clear();
        inventoryList.addAll(inventoryRepo.getAll(username));

        // RecyclerView adapter with quantity change listeners
        inventoryAdapter = new InventoryAdapter(inventoryList, new InventoryAdapter.QuantityListener() {
            @Override
            public void onIncrease(InventoryItem item, int position) {
                item.setQuantity(item.getQuantity() + 1);
                inventoryRepo.updateQuantity(username, item.getName(), item.getQuantity());
                inventoryAdapter.notifyItemChanged(position);
            }

            @Override
            public void onDecrease(InventoryItem item, int position) {
                int newQty = Math.max(0, item.getQuantity() - 1);
                item.setQuantity(newQty);
                inventoryRepo.updateQuantity(username, item.getName(), newQty);
                inventoryAdapter.notifyItemChanged(position);
                maybeSendLowStockAlert(item); // check if SMS alert should fire
            }

            @Override
            public void onDelete(InventoryItem item, int position) {
                inventoryRepo.delete(username, item.getName());
                inventoryList.remove(position);
                inventoryAdapter.notifyItemRemoved(position);
            }
        });
        inventoryGrid.setAdapter(inventoryAdapter);

        // floating action button actions
        fabAddItem.setOnClickListener(v -> openAddItemDialog());
        fabRemoveItem.setOnClickListener(v -> removeLastItem());

        // exit app: wipe session and close everything
        fabExit.setOnClickListener(v -> {
            clearSession();
            finishAffinity();
        });
    }

    /**
     * ensure session is cleared when activity is finishing (e.g. user hit exit)
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isFinishing()) {
            clearSession();
        }
    }

    /**
     * helper: clear saved user session
     */
    private void clearSession() {
        getSharedPreferences("session", MODE_PRIVATE).edit().clear().apply();
    }

    /**
     * dialog for adding a new item.
     * prompts for item name and initial quantity.
     * saves to DB and updates RecyclerView.
     */
    private void openAddItemDialog() {
        android.widget.LinearLayout container = new android.widget.LinearLayout(this);
        container.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        container.setPadding(pad, pad, pad, pad);

        // item name input
        final android.widget.EditText nameInput = new android.widget.EditText(this);
        nameInput.setHint("Item name:");
        nameInput.setSingleLine(true);
        container.addView(nameInput);

        // quantity input
        final android.widget.EditText qtyInput = new android.widget.EditText(this);
        qtyInput.setHint("Initial quantity (greater than: 1):");
        qtyInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        container.addView(qtyInput);

        // Build and show dialog
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Create Inventory Item")
                .setView(container)
                .setPositiveButton("Add", (d, w) -> {
                    String name = nameInput.getText().toString().trim();
                    String qtyStr = qtyInput.getText().toString().trim();

                    // validate
                    if (name.isEmpty()) {
                        android.widget.Toast.makeText(this, "Item Name:", android.widget.Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int qty = 0;
                    try { qty = Integer.parseInt(qtyStr); } catch (Exception ignored) {}
                    if (qty < 0) qty = 0;

                    // upsert into DB
                    inventoryRepo.upsert(username, name, qty);

                    // update list and send adapter a memo
                    int existingIndex = -1;
                    for (int i = 0; i < inventoryList.size(); i++) {
                        if (inventoryList.get(i).getName().equalsIgnoreCase(name)) {
                            existingIndex = i; break;
                        }
                    }
                    if (existingIndex >= 0) {
                        inventoryList.get(existingIndex).setQuantity(qty);
                        inventoryAdapter.notifyItemChanged(existingIndex);
                        inventoryGrid.scrollToPosition(existingIndex);
                    } else {
                        InventoryItem item = new InventoryItem(name, qty);
                        inventoryList.add(item);
                        int pos = inventoryList.size() - 1;
                        inventoryAdapter.notifyItemInserted(pos);
                        inventoryGrid.scrollToPosition(pos);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * removes the last item in the list (convenience delete).
     */
    private void removeLastItem() {
        if (inventoryList.isEmpty()) return;
        int last = inventoryList.size() - 1;
        InventoryItem item = inventoryList.get(last);
        inventoryRepo.delete(username, item.getName());
        inventoryList.remove(last);
        inventoryAdapter.notifyItemRemoved(last);
    }

    /**
     * sends SMS alert if item quantity falls below 1
     * and SMS permission/setting is enabled.
     */
    private void maybeSendLowStockAlert(InventoryItem item) {
        if (item.getQuantity() >= LOW_STOCK_THRESHOLD) return;

        SharedPreferences prefs = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        boolean smsEnabled = prefs.getBoolean("sms_enabled", false);
        if (!smsEnabled) return;

        // check runtime SMS permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        //get user’s saved phone number
        String phone = userRepo.getPhone(username);
        if (phone == null || phone.trim().isEmpty()) return;

        try {
            // send SMS alert
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null,
                    "Stack & Stock alert: \"" + item.getName() + "\" is low (" + item.getQuantity() + ").",
                    null, null);
            Toast.makeText(this, "Low-stock SMS sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {
            // Do nothing if emulator/device can not send SMS
        }
    }
}