package com.example.ericapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * repository class that handles all database operations
 */
public class InventoryRepository {
    private final AppDatabase dbHelper; //  for managing DB connection

    public InventoryRepository(Context ctx) {
        this.dbHelper = new AppDatabase(ctx);
    }

    /**
     * get all inventory items for user, sorted by name.
     */
    public List<InventoryItem> getAll(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(
                AppDatabase.T_INVENTORY,             // Table
                new String[]{"name", "quantity"},    // Columns to return
                "username=?",                        // WHERE clause
                new String[]{username},              // WHERE args
                null, null,
                "name ASC");                         // Order by name

        List<InventoryItem> out = new ArrayList<>();
        while (c.moveToNext()) {
            // create InventoryItem objects
            out.add(new InventoryItem(c.getString(0), c.getInt(1)));
        }
        c.close(); //  prevent memory leaks
        return out;
    }

    /**
     * insert or update an inventory item for a user.
     * if the item already exists, it is replaced.
     */
    public void upsert(String username, String name, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("name", name);
        cv.put("quantity", Math.max(0, quantity)); // avoid negative numbers
        db.insertWithOnConflict(
                AppDatabase.T_INVENTORY,
                null,
                cv,
                SQLiteDatabase.CONFLICT_REPLACE); //  conflict resolution (upsert)
    }

    /**
     * update the quantity of a specific item for a user.
     */
    public void updateQuantity(String username, String name, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("quantity", Math.max(0, quantity));
        db.update(
                AppDatabase.T_INVENTORY,
                cv,
                "username=? AND name=?",
                new String[]{username, name});
    }

    /**
     * delete a specific item from a user's inventory.
          */
    public void delete(String username, String name) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(
                AppDatabase.T_INVENTORY,
                "username=? AND name=?",
                new String[]{username, name});
    }
}